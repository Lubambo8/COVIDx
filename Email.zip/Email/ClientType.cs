﻿namespace Utility.Email
{
    public enum ClientType
    {
        Google,
        Microsoft
    }
}
